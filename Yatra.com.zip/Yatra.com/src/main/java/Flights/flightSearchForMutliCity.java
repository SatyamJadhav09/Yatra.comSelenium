package Flights;

import java.io.IOException;
import java.time.Duration;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

import Repository.FSearchMRp;
import Repository.FSearchRp;
import file.read.pkg.FileRead;
import io.github.bonigarcia.wdm.WebDriverManager;

public class flightSearchForMutliCity
{

	public static void main(String[] args) throws InterruptedException, IOException 
	{
		WebDriverManager.edgedriver().setup();
		WebDriver driver=new EdgeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.yatra.com/");
		
		XSSFSheet sh1=FileRead.readF("Destinations");
		String C1=sh1.getRow(0).getCell(0).toString();
		String C2=sh1.getRow(1).getCell(0).toString();
		String C3=sh1.getRow(2).getCell(0).toString();
		
		System.out.println(C1+" | "+C2+" | "+C3);
		
		FSearchMRp.multiCity(driver).click();
		System.out.println("Multi-city selected");
		
		FSearchMRp.dpartFrom1(driver).click();
		Thread.sleep(5000);
		FSearchMRp.dpartFrom1(driver).sendKeys(C1);
		Thread.sleep(5000);
		FSearchMRp.dpartFrom1(driver).sendKeys(Keys.ENTER);
		System.out.println("First city is selected: "+C1);
		
		
		FSearchMRp.arriveAt1(driver).click();
		Thread.sleep(5000);
		FSearchMRp.arriveAt1(driver).sendKeys(C2);
		Thread.sleep(5000);
		FSearchMRp.arriveAt1(driver).sendKeys(Keys.ENTER);
		System.out.println("Second city seleceted: "+C2);
		
		FSearchMRp.onBoardDate1(driver).click();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(7));
		FSearchMRp.date1(driver).click();
		System.out.println("Date1 is selected");
		
		FSearchMRp.arriveAt2(driver).click();
		Thread.sleep(5000);
		FSearchMRp.arriveAt2(driver).sendKeys(C3);
		Thread.sleep(5000);
		FSearchMRp.arriveAt2(driver).sendKeys(Keys.ENTER);
		System.out.println("Third city is selected: "+C3);
		
		FSearchMRp.dpartdate(driver).click();
		FSearchMRp.date2(driver).click();
		System.out.println("Date 2 selected");
		
		FSearchRp.numberOfSits(driver).click();
		
		FSearchRp.adultsPlus(driver).click();
		FSearchRp.adultsPlus(driver).click();
		System.out.println("Num of adults are selected");
		
		FSearchRp.childPlus(driver).click();
		FSearchRp.childPlus(driver).click();
		System.out.println("Num of childrens are seleceted");
		
		FSearchRp.infantPlus(driver).click();
		System.out.println("Num of infant are selected");
		
		FSearchMRp.business(driver).click();
		System.out.println("Business class selecetd");
		
		FSearchRp.nonStopFlights(driver).click();
		System.out.println("Non stop flight selected");
		
		Thread.sleep(5000);
		
		FSearchRp.flightSearch(driver).click();
		System.out.println("Flight search for Multi-city is completed");
		
		System.out.println(driver.findElement(By.tagName("body")).getText());
		driver.close();
		
	}

}
