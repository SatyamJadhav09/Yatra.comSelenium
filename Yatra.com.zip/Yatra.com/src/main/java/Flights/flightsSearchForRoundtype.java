package Flights;

import java.io.IOException;
import java.time.Duration;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import Loginpkg.Login;
import Repository.FSearchRp;
import file.read.pkg.FileRead;
import io.github.bonigarcia.wdm.WebDriverManager;

public class flightsSearchForRoundtype 
{

	public static void main(String[] args) throws IOException, InterruptedException 
	{		
		WebDriverManager.edgedriver().setup();
		WebDriver driver=new EdgeDriver();
		Actions act=new Actions(driver);
		//Login.LoginM(driver);
		driver.manage().window().maximize();
		driver.get("https://www.yatra.com/");
		
		
		
		
		Thread.sleep(5000);
	
		
		try
		{
		WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(10));
		wait.until(ExpectedConditions.elementToBeClickable(FSearchRp.tripType(driver)));
		FSearchRp.tripType(driver).click();
		}
		catch(Exception e)
		{}
	
		System.out.println("Return type flight is selected");		
		XSSFSheet sh1=FileRead.readF("Destinations");
		String SF=sh1.getRow(0).getCell(0).toString();
		String Dest=sh1.getRow(1).getCell(0).toString();
		
		System.out.println(SF +" , " +Dest);
		
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
	//	act.moveToElement(FSearch.dpartFrom(driver)).click().build().perform();
		FSearchRp.dpartFrom(driver).click();
		Thread.sleep(5000);
		FSearchRp.dpartFrom(driver).sendKeys(SF);
		Thread.sleep(4000);
		FSearchRp.dpartFrom(driver).sendKeys(Keys.ENTER);
		System.out.println(SF+" is selected");
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		FSearchRp.arriveAt(driver).clear();
		Thread.sleep(5000);
		FSearchRp.arriveAt(driver).sendKeys(Dest);
		Thread.sleep(5000);
		FSearchRp.arriveAt(driver).sendKeys(Keys.ENTER);
		System.out.println(Dest+" is selected");
		
	
		FSearchRp.onBoardDate(driver).click();
		FSearchRp.date1(driver).click();
		FSearchRp.date2(driver).click();

		
		FSearchRp.numberOfSits(driver).click();
		WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(10));
		wait.until(ExpectedConditions.elementToBeClickable(FSearchRp.adultsPlus(driver)));
		FSearchRp.adultsPlus(driver).click();
		System.out.println(" No. of Adults are selected");
		
		FSearchRp.childPlus(driver).click();
		System.out.println("NO. of children are selected");
		
		FSearchRp.infantPlus(driver).click();
		System.out.println("No. of infant are selected");
		
		FSearchRp.preEco(driver).click();
		System.out.println("Pre Economy class is selected");
		
		FSearchRp.nonStopFlights(driver).click();
		System.out.println("Non stop file is seleceted");
		
		Thread.sleep(6000);
		FSearchRp.flightSearch(driver).click();
		Thread.sleep(5000);
		System.out.println(driver.findElement(By.tagName("body")).getText());
		System.out.println("Flight search for round trip is successful");
		
		
		
		driver.close();
		
	}

}
