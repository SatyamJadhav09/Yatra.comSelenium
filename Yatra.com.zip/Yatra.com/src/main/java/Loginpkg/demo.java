package Loginpkg;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.Duration;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import Repository.LoginCred;
import file.read.pkg.FileRead;
import io.github.bonigarcia.wdm.WebDriverManager;

public class demo
{

	public static void main(String[] args) throws IOException, InterruptedException
	{
		WebDriverManager.chromedriver().setup();
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.yatra.com/");


		XSSFSheet sh1=FileRead.readF("Sheet1");
		for(int i=1;i<=3;i++)
		{
			String mobNo=sh1.getRow(i).getCell(0).toString();
			System.out.println(mobNo);
			Actions act=new Actions(driver);
			act.moveToElement(LoginCred.Myaccount(driver)).click().build().perform();
			WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(4));
			wait.until(ExpectedConditions.elementToBeClickable(LoginCred.login(driver)));
			LoginCred.login(driver).click();
			LoginCred.mobNo(driver).sendKeys(mobNo);
			try
			{
				LoginCred.continueOtp(driver).click();
				Thread.sleep(30000);
				LoginCred.submit(driver).click();
				System.out.println("Login successful");
				Thread.sleep(5000);
				LoginCred.linkForLogout(driver).click();
				LoginCred.logout(driver).click();
			}
			catch(Exception e)
			{
				System.out.println("Login failed");
				driver.get("https://www.yatra.com/");
			}
		}
		driver.close();




	}

}
