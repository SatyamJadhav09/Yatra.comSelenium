package HotelsByCity;

import java.io.IOException;
import java.time.Duration;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import Repository.HotelSearchRp;
import file.read.pkg.FileRead;
import io.github.bonigarcia.wdm.WebDriverManager;

public class hotelsSearchBycity
{

	public static void hotelSearchCity(WebDriver driver) throws IOException, InterruptedException
	{

		driver.manage().window().maximize();
		driver.get("https://www.yatra.com/");
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		try
		{
			driver.switchTo().frame("webpush-onsite");
			driver.findElement(By.xpath("/html/body/div/div[2]/div[2]/button[1]")).click();
		}
		catch(Exception e)
		{
			driver.close();
		}
		driver.switchTo().parentFrame();
		XSSFSheet sh1=FileRead.readF("Destinations");
		String city=sh1.getRow(2).getCell(0).toString();
		System.out.println(city);
		HotelSearchRp.hotels(driver).click();

		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		HotelSearchRp.citySelect(driver).click();
		Thread.sleep(6000);
		HotelSearchRp.citySelect(driver).clear();
		Thread.sleep(5000);
		HotelSearchRp.citySelect(driver).sendKeys(city);
		Thread.sleep(5000);
		HotelSearchRp.citySelect(driver).sendKeys(Keys.ENTER);
		System.out.println("City selected");

		HotelSearchRp.checkInDate(driver).click();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		HotelSearchRp.date1(driver).click();
		System.out.println("Date1 selecetd: "+HotelSearchRp.date1(driver).getText());

		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		HotelSearchRp.date2(driver).click();
		System.out.println("Date2 selected");


		HotelSearchRp.dropDown(driver).click();
		HotelSearchRp.room1AdultPlus(driver).click();
		HotelSearchRp.room1ChildPlus(driver).click();
		System.out.println("For room1 room member selected");

		Select age=new Select(HotelSearchRp.ageOfChild1(driver));
		age.selectByIndex(2);

		WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(10));
		wait.until(ExpectedConditions.elementToBeClickable(HotelSearchRp.addRoom(driver)));
		HotelSearchRp.addRoom(driver).click();
		HotelSearchRp.room2AdultMinus(driver).click();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		HotelSearchRp.room2ChildPlus(driver).click();
		System.out.println("For room2 room member selected");

		Select age2=new Select(HotelSearchRp.ageOfChild2(driver));
		age2.selectByValue("8");
		HotelSearchRp.removeRoom(driver).click();
		System.out.println("room 2 deleted");
		Thread.sleep(6000);
		HotelSearchRp.searchHotels(driver).click();
		Thread.sleep(6000);
		System.out.println("Success!");
		

	}

}
