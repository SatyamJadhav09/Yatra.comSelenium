package HotelsByCity;

import java.io.File;
import java.io.IOException;
import java.time.Duration;

import org.apache.commons.io.FileUtils;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import Repository.PaymentRp;
import file.read.pkg.FileRead;

public class PaymentPage
{
	public static void PayPage(WebDriver driver) throws IOException
	{
		XSSFSheet sh1=FileRead.readF("Email");
		String mailid=sh1.getRow(1).getCell(0).toString();
		System.out.println(mailid);
		
		XSSFSheet sh2=FileRead.readF("Login");
		String mobNo=sh2.getRow(1).getCell(0).toString();
		System.out.println(mobNo);
		
		JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("arguments[0].scrollIntoView();", PaymentRp.mail(driver));
		
		PaymentRp.mail(driver).sendKeys(mailid);
		
		PaymentRp.mobNo(driver).sendKeys(mobNo);
		
		Select obj=new Select(PaymentRp.title(driver));
		obj.selectByValue("Mr");
		
		PaymentRp.firstName(driver).sendKeys("Satyam");
		PaymentRp.lastName(driver).sendKeys("Jadhav");
		
		PaymentRp.continueForPayment(driver).click();
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		PaymentRp.gPay(driver).click();
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		PaymentRp.mobNoOfGPay(driver).sendKeys(mobNo);
		
		PaymentRp.payNow(driver).click();
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		PaymentRp.paymentWithoutPromocode(driver).click();
		System.out.println(PaymentRp.paymentInitiated(driver).getText());
		
		File fs=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);			//Taking screenshot
		FileUtils.copyFile(fs, new File("C:\\\\Users\\\\HP\\\\Desktop\\\\payment1.png"));
	}
}
