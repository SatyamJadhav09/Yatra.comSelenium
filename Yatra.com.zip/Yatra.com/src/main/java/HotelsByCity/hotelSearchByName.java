package HotelsByCity;

import java.io.File;
import java.io.IOException;
import java.time.Duration;

import org.apache.commons.io.FileUtils;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import Repository.HotelSearchByNameRp;
import file.read.pkg.FileRead;
import io.github.bonigarcia.wdm.WebDriverManager;

public class hotelSearchByName 
{

	public static void main(String[] args) throws IOException, InterruptedException
	{
		WebDriverManager.edgedriver().setup();
		WebDriver driver=new EdgeDriver();
		hotelsSearchBycity.hotelSearchCity(driver);
		System.out.println("Double success");
		
		XSSFSheet sh1=FileRead.readF("HotelNames");
		String Hname=sh1.getRow(2).getCell(0).toString();
		System.out.println(Hname);
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		HotelSearchByNameRp.searchBar(driver).sendKeys(Hname);
		Thread.sleep(5000);
		HotelSearchByNameRp.searchBar(driver).sendKeys(Keys.ENTER);
		
		String win1 = driver.getWindowHandle();
		
		WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(10));
		wait.until(ExpectedConditions.elementToBeClickable(HotelSearchByNameRp.linkOfHotel(driver)));
		HotelSearchByNameRp.linkOfHotel(driver).click();
		
		
		for(String wins : driver.getWindowHandles())
		{
		    driver.switchTo().window(wins);			//  Switching to new window opened
		}
		
		wait.until(ExpectedConditions.elementToBeClickable(HotelSearchByNameRp.checkInDate(driver)));
		
		HotelSearchByNameRp.checkInDate(driver).click();
		
		
		HotelSearchByNameRp.date1(driver).click();
		HotelSearchByNameRp.date2(driver).click();
		
		Actions act=new Actions(driver);
		act.moveToElement(HotelSearchByNameRp.guests(driver)).build().perform();
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		Thread.sleep(5000);
	//	HotelSearchByNameRp.removeRoom(driver).clear();
	//	HotelSearchByNameRp.adultMinus(driver).click();
		HotelSearchByNameRp.adultMinus(driver).click();
		
		//HotelSearchByNameRp.childPlus(driver);
		//Select age=new Select(HotelSearchByNameRp.ageOfChild1(driver));
		//age.selectByIndex(5);
		
		System.out.println("Guests are selected");
		
		JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("arguments[0].scrollIntoView();",HotelSearchByNameRp.checkAvailability(driver));
		HotelSearchByNameRp.checkAvailability(driver).click();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		HotelSearchByNameRp.bookNow(driver).click();
				
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(80));
		
		File sf=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);  		//Taking screenshot
		FileUtils.copyFile(sf, new File("C:\\Users\\HP\\Desktop\\amountDetails.png"));	//Saving the file with destination and name of file with extension png
		System.out.println("Success!");
		
		PaymentPage.PayPage(driver);

		driver.quit();
		
	
		/*HotelSearchByNameRp
		JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("arguments[0].scrollIntoView();", HotelSearchByNameRp.checkInDate(driver));
		HotelSearchByNameRp
		HotelSearchByNameRp
		HotelSearchByNameRp
		HotelSearchByNameRp
		HotelSearchByNameRp
		
		*/
	


	}

}
