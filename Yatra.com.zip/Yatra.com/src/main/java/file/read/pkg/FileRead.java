package file.read.pkg;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class FileRead 
{
	public static XSSFSheet readF(String shName) throws IOException
	{
		File fs=new File("Data/Data.xlsx");
		FileInputStream fis=new FileInputStream(fs);
		XSSFWorkbook wb=new XSSFWorkbook(fis);
		XSSFSheet sh1=wb.getSheet(shName);
		return sh1;
	}
}
