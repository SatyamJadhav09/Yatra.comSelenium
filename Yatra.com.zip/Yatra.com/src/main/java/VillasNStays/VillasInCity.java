package VillasNStays;

import java.io.File;
import java.io.IOException;
import java.time.Duration;

import org.apache.commons.io.FileUtils;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import Repository.HotelSearchRp;
import Repository.VillasRp;
import file.read.pkg.FileRead;
import io.github.bonigarcia.wdm.WebDriverManager;

public class VillasInCity
{

	public static void main(String[] args) throws IOException, InterruptedException
	{
		WebDriverManager.edgedriver().setup();
		WebDriver driver=new EdgeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.yatra.com/");
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		try
		{
			driver.switchTo().frame("webpush-onsite");
			driver.findElement(By.xpath("/html/body/div/div[2]/div[2]/button[1]")).click();
		}
		catch(Exception e)
		{
			driver.close();
		}
		driver.switchTo().parentFrame();
		
		XSSFSheet sh1=FileRead.readF("Destinations");
		String City=sh1.getRow(4).getCell(0).toString();
		System.out.println(City);
		
		VillasRp.hotelsNVillas(driver).click();
		
		HotelSearchRp.citySelect(driver).click();
		//HotelSearchRp.citySelect(driver).clear();
		Thread.sleep(5000);
		HotelSearchRp.citySelect(driver).sendKeys(City);
		Thread.sleep(5000);
		HotelSearchRp.citySelect(driver).sendKeys(Keys.ENTER);
		
		HotelSearchRp.checkInDate(driver).click();
		HotelSearchRp.date1(driver).click();
		
		HotelSearchRp.date2(driver).click();
		
		VillasRp.searchVillas(driver).click();
		System.out.println("Villas search complete");
		
		WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(10));
		wait.until(ExpectedConditions.visibilityOfAllElements(VillasRp.priceRange(driver)));
		VillasRp.priceRange(driver).click();
		
		VillasRp.freeWiFi(driver).click();
		
		JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("arguments[0].scrollIntoView();", VillasRp.scrollLocalities(driver));
		
		VillasRp.localities(driver).click();
		VillasRp.homeStays(driver).click();
		
		//String window1=driver.getWindowHandle();
		
		VillasRp.HomestayName(driver).click();
		System.out.println("Villa selected");
		
		for(String wins : driver.getWindowHandles())
		{
			driver.switchTo().window(wins);
		}
		
		wait.until(ExpectedConditions.visibilityOf(VillasRp.checkAvailability(driver)));
		VillasRp.checkAvailability(driver).click();
		
		wait.until(ExpectedConditions.visibilityOf(VillasRp.bookNow(driver)));
		VillasRp.bookNow(driver).click();
		
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(80));
		
		File sf=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);		//Taking screenshot
		FileUtils.copyFile(sf, new File("C:\\\\Users\\\\HP\\\\Desktop\\\\amountDetailsOfVilla.png"));		//Saving file in the folder with name and extension
		
		System.out.println("Success!");
		driver.quit();
	}

}
