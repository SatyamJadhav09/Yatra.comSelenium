package Holidays;

import java.io.File;
import java.io.IOException;
import java.time.Duration;

import org.apache.commons.io.FileUtils;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import Repository.HolidaysRp;
import file.read.pkg.FileRead;
import io.github.bonigarcia.wdm.WebDriverManager;

public class ladakhHolidays
{

	public static void main(String[] args) throws IOException, InterruptedException
	{
		WebDriverManager.edgedriver().setup();
		WebDriver driver=new EdgeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.yatra.com/");

		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		try
		{
			driver.switchTo().frame("webpush-onsite");
			driver.findElement(By.xpath("/html/body/div/div[2]/div[2]/button[1]")).click();
		}
		catch(Exception e)
		{
			driver.close();
		}
		driver.switchTo().parentFrame();

		XSSFSheet sh1=FileRead.readF("Destinations");
		String city1=sh1.getRow(4).getCell(0).toString();
		String city2=sh1.getRow(5).getCell(0).toString();
		System.out.println(city1+" , "+city2);

		HolidaysRp.holidays(driver).click();

		HolidaysRp.departFrom(driver).click();
		Thread.sleep(4000);
		HolidaysRp.departFrom(driver).sendKeys(city1);
		Thread.sleep(4000);
		HolidaysRp.departFrom(driver).sendKeys(Keys.ENTER);
		Thread.sleep(4000);
		HolidaysRp.goingTo(driver).click();
		Thread.sleep(4000);
		HolidaysRp.goingTo(driver).sendKeys(city2);
		Thread.sleep(4000);
		HolidaysRp.goingTo(driver).sendKeys(Keys.ENTER);

		HolidaysRp.monthOfTravel(driver).click();
		HolidaysRp.month(driver).click();
		HolidaysRp.searchHolidayButton(driver).click();
		System.out.println("Holiday search complete in city "+city2);
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		HolidaysRp.IndusCreedStandard(driver).click();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		HolidaysRp.bookNow(driver).click();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		Select ob=new Select(HolidaysRp.coustomerState(driver));
		ob.selectByValue("20");			//Maharashtra-20
		HolidaysRp.proceed(driver).click();
		WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(30));
		wait.until(ExpectedConditions.elementToBeClickable(HolidaysRp.pdfDownload(driver)));
		
		File sf=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(sf, new File("C:\\Users\\HP\\Desktop\\amount deatails for ladakh.png"));
		HolidaysRp.pdfDownload(driver).click();
		
		

		//HolidaysRp
		Thread.sleep(10000);
		System.out.println("Success!");
		driver.close();

	}

}
