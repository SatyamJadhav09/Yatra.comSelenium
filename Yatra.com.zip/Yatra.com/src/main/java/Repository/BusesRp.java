package Repository;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class BusesRp
{
	public static WebElement elem;
	
	public static WebElement busesIcon(WebDriver driver)
	{
		elem=driver.findElement(By.id("booking_engine_buses"));
		return elem;
	}
	
	public static WebElement departFrom(WebDriver driver)
	{
		elem=driver.findElement(By.id("BE_bus_from_station"));
		return elem;
	}
	
	//for mumbai to pune
	public static WebElement goingTo(WebDriver driver)
	{
		elem=driver.findElement(By.id("BE_bus_to_station"));
		return elem;
	}
	
	public static WebElement departDate(WebDriver driver)
	{
		elem=driver.findElement(By.id("BE_bus_depart_date"));
		return elem;
	}
	
	public static WebElement date(WebDriver driver)
	{
		elem=driver.findElement(By.id("18/08/2022"));
		return elem;
	}
	
	public static WebElement busSearchButton(WebDriver driver)
	{
		elem=driver.findElement(By.id("BE_bus_search_btn"));
		return elem;
	}
	
	public static WebElement manishTravels(WebDriver driver)
	{
		elem=driver.findElement(By.xpath("/html[1]/body[1]/div[1]/div[1]/div[6]/div[18]/div[1]/div[6]/button[1]/div[1]"));
		return elem;
	}
	
	public static WebElement selectSeat(WebDriver driver)
	{
		elem=driver.findElement(By.xpath("/html[1]/body[1]/div[1]/div[1]/div[6]/div[18]/div[1]/div[6]/button[1]/div[1]"));
		return elem;
	}
	
	public static WebElement seat1(WebDriver driver)
	{
		elem=driver.findElement(By.xpath("/html[1]/body[1]/div[1]/div[1]/div[6]/div[789]/div[1]/section[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/ul[1]/li[4]/i[1]"));
		return elem;
	}
	
	
	
	public static WebElement seat2(WebDriver driver)
	{
		elem=driver.findElement(By.xpath("/html[1]/body[1]/div[1]/div[1]/div[6]/div[789]/div[1]/section[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/ul[1]/li[5]/i[1]"));
		return elem;
	}
	
	public static WebElement selectBoardingPoint(WebDriver driver)
	{
		elem=driver.findElement(By.xpath("/html[1]/body[1]/div[1]/div[1]/div[6]/div[789]/div[1]/section[1]/div[2]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/select[1]"));
		return elem;
	}
	
	public static WebElement selectDroppingPoints(WebDriver driver)
	{
		elem=driver.findElement(By.xpath("/html[1]/body[1]/div[1]/div[1]/div[6]/div[789]/div[1]/section[1]/div[2]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/select[1]"));
		return elem;
	}
	
	public static WebElement conformSeats(WebDriver driver)
	{
		elem=driver.findElement(By.xpath("/html[1]/body[1]/div[1]/div[1]/div[6]/div[789]/div[1]/section[1]/div[2]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/button[1]/div[1]"));
		return elem;
	}
	
	
}
