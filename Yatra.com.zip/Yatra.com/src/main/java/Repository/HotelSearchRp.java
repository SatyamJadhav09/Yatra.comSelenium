package Repository;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class HotelSearchRp
{
	public static WebElement elem;
	public static WebElement hotels(WebDriver driver)
	{
		elem=driver.findElement(By.id("booking_engine_hotels"));
		return elem;
	}

	public static WebElement citySelect(WebDriver driver) 
	{	
		elem=driver.findElement(By.id("BE_hotel_destination_city"));
		return elem;
	}

	public static WebElement checkInDate(WebDriver driver)
	{
		elem=driver.findElement(By.id("BE_hotel_checkin_date"));
		return elem;
	}

	public static WebElement date1(WebDriver driver)
	{
		elem=driver.findElement(By.id("05/08/2022"));
		return elem;
	}

	public static WebElement checkOutDate(WebDriver driver)
	{
		elem=driver.findElement(By.id("BE_hotel_checkout_date"));
		return elem;
	}

	public static WebElement date2(WebDriver driver)
	{
		elem=driver.findElement(By.id("08/08/2022"));
		return elem;
	}

	public static WebElement dropDown(WebDriver driver)
	{
		elem=driver.findElement(By.id("BE_Hotel_pax_info"));
		return elem;			
	}

	public static WebElement room1AdultPlus(WebDriver driver)
	{
		elem=driver.findElement(By.xpath("//body/div[2]/div[1]/section[1]/div[1]/div[1]/div[1]/section[1]/div[1]/div[1]/div[1]/div[1]/div[3]/div[1]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/span[2]"));
		return elem;
	}

	public static WebElement room1ChildPlus(WebDriver driver)
	{
		elem=driver.findElement(By.xpath("//body/div[2]/div[1]/section[1]/div[1]/div[1]/div[1]/section[1]/div[1]/div[1]/div[1]/div[1]/div[3]/div[1]/div[1]/div[1]/div[2]/div[3]/div[1]/div[1]/span[2]"));
		return elem;
	}

	public static WebElement ageOfChild1(WebDriver driver)
	{
		elem=driver.findElement(By.className("ageselect"));
		return elem;
	}
	
	
	public static WebElement addRoom(WebDriver driver)
	{
		elem=driver.findElement(By.xpath("//a[contains(text(),'Add room')]"));
		return elem;

	}

	public static WebElement room2AdultMinus(WebDriver driver)
	{
		elem=driver.findElement(By.xpath("//body/div[2]/div[1]/section[1]/div[1]/div[1]/div[1]/section[1]/div[1]/div[1]/div[1]/div[1]/div[3]/div[1]/div[1]/div[2]/div[2]/div[2]/div[1]/div[1]/span[1]"));
		return elem;
	}

	public static WebElement room2ChildPlus(WebDriver driver)
	{
		elem=driver.findElement(By.xpath("//body/div[2]/div[1]/section[1]/div[1]/div[1]/div[1]/section[1]/div[1]/div[1]/div[1]/div[1]/div[3]/div[1]/div[1]/div[2]/div[2]/div[3]/div[1]/div[1]/span[2]"));
		return elem;
	}
	
	public static WebElement ageOfChild2(WebDriver driver)
	{
		elem=driver.findElement(By.xpath("//body/div[2]/div[1]/section[1]/div[1]/div[1]/div[1]/section[1]/div[1]/div[1]/div[1]/div[1]/div[3]/div[1]/div[1]/div[2]/ul[1]/li[2]/div[1]/select[1]"));
		return elem;
	}

	public static WebElement removeRoom(WebDriver driver)
	{
		elem=driver.findElement(By.linkText("Remove room"));
		return elem;
	}
	public static WebElement searchHotels(WebDriver driver)
	{
		elem=driver.findElement(By.id("BE_hotel_htsearch_btn"));
		return elem;
	}

}
