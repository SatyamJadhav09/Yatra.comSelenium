package Repository;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class HolidaysRp 
{
	public static WebElement elem;

	public static WebElement holidays(WebDriver driver)
	{
		elem=driver.findElement(By.id("booking_engine_holidays"));
		return elem;
	}

	public static WebElement departFrom(WebDriver driver)		//pune
	{
		elem=driver.findElement(By.id("BE_holiday_leaving_city"));
		return elem;
	}

	public static WebElement goingTo(WebDriver driver)		//ladakh
	{
		elem=driver.findElement(By.id("holiday_destination_city"));
		return elem;
	}

	public static WebElement monthOfTravel(WebDriver driver)
	{
		elem=driver.findElement(By.xpath("//body/div[2]/div[1]/section[1]/div[1]/div[1]/div[1]/section[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/span[3]"));
		return elem;
	}
	public static WebElement searchHolidayButton(WebDriver driver)
	{
		elem=driver.findElement(By.id("BE_holiday_search_btn"));
		return elem;
	}

	public static WebElement text(WebDriver driver)
	{
		elem=driver.findElement(By.xpath("/html[1]/body[1]/div[2]/section[2]/div[2]/div[1]/p[1]"));
		return elem;
	}

	public static WebElement holidayMonth(WebDriver driver)
	{
		elem=driver.findElement(By.xpath("/html[1]/body[1]/div[2]/section[1]/div[1]/div[1]/div[1]/div[2]/div[3]"));
		return elem;
	}

	public static WebElement month(WebDriver driver)
	{
		elem=driver.findElement(By.xpath("//*[@id=\"BE_holiday_destination_details\"]/div/div/div/div[2]/div/div/ul/li[3]/span"));
		return elem;
	}
	public static WebElement modifySearch(WebDriver driver)
	{
		elem=driver.findElement(By.xpath("/html[1]/body[1]/div[2]/section[1]/div[1]/div[1]/div[1]/div[2]/button[1]"));
		return elem;
	}
	public static WebElement closingFrame(WebDriver driver)
	{
		elem=driver.findElement(By.linkText("×"));
		return elem;
	}

	public static WebElement price(WebDriver driver)
	{
		elem=driver.findElement(By.linkText("Price"));
		return elem;
	}

	public static WebElement IndusCreedStandard(WebDriver driver)
	{
		elem=driver.findElement(By.linkText("Indus Creed - Standard"));
		return elem;
	}

	public static WebElement closingFrame2(WebDriver driver)
	{
		elem=driver.findElement(By.xpath("//body/div[5]/section[1]/div[2]/a[1]/a[1]/i[1]"));
		return elem;
	}



	public static WebElement bookNow(WebDriver driver)
	{
		elem=driver.findElement(By.xpath("/html[1]/body[1]/main[1]/div[2]/div[1]/div[1]/div[2]/button[1]"));
		return elem;
	}

	public static WebElement coustomerState(WebDriver driver)
	{
		elem=driver.findElement(By.xpath("/html[1]/body[1]/main[1]/depart-calendar[1]/div[1]/section[1]/div[3]/div[1]/div[3]/span[1]/select[1]"));
		return elem;
	}


	public static WebElement proceed(WebDriver driver)
	{
		elem=driver.findElement(By.xpath("/html[1]/body[1]/main[1]/depart-calendar[1]/div[1]/section[1]/div[3]/div[3]/button[1]"));
		return elem;
	}


	
	public static WebElement pdfDownload(WebDriver driver)
	{
		elem=driver.findElement(By.xpath("/html[1]/body[1]/div[6]/div[5]/div[2]/span[2]"));
		return elem;
	}





/*	public static WebElement holidays(WebDriver driver)
	{
		elem=driver.findElement(By);
		return elem;
	}*/

}
