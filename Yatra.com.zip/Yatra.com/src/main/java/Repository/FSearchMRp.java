package Repository;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class FSearchMRp 
{
	public static WebElement elem;

	public static WebElement multiCity(WebDriver driver)
	{
		elem=driver.findElement(By.xpath("//body/div[2]/div[1]/section[1]/div[1]/div[1]/div[1]/section[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/ul[1]/li[3]/a[1]"));
		return elem;
	}

	public static WebElement dpartFrom1(WebDriver driver)
	{
		elem=driver.findElement(By.id("BE_flight_origin_city_1"));
		return elem;
	}

	public static WebElement arriveAt1(WebDriver driver)
	{
		elem=driver.findElement(By.id("BE_flight_arrival_city1"));
		return elem;
	}
	
	public static WebElement onBoardDate1(WebDriver driver)
	{
		elem=driver.findElement(By.id("BE_flight_origin_date_1"));
		return elem;
	}
	
	public static WebElement date1(WebDriver driver)
	{
		elem=driver.findElement(By.id("12/07/2022"));
		return elem;
	}
	
	public static WebElement arriveAt2(WebDriver driver)
	{
		elem=driver.findElement(By.id("BE_flight_arrival_city2"));
		return elem;
	}
	
	
	public static WebElement dpartdate(WebDriver driver)
	{
		elem=driver.findElement(By.id("BE_flight_origin_date_2"));
		return elem;
	}
	
	public static WebElement date2(WebDriver driver)
	{
		elem=driver.findElement(By.id("20/07/2022"));
		return elem;
	}
	
	public static WebElement business(WebDriver driver)
	{
		elem=driver.findElement(By.xpath("//body/div[2]/div[1]/section[1]/div[1]/div[1]/div[1]/section[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[2]/div[1]/div[1]/ul[1]/li[3]/span[1]"));
		return elem;
	}
	
	
}
