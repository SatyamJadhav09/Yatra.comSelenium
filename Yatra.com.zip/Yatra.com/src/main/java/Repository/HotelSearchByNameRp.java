package Repository;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class HotelSearchByNameRp
{
	public static WebElement elem;
	
	public static WebElement searchBar(WebDriver driver)
	{
		elem=driver.findElement(By.id("hotelFilterInput"));
		return elem;
	}
	
	public static WebElement linkOfHotel(WebDriver driver)
	{
		elem=driver.findElement(By.linkText("Hotel The Royal Plaza"));
		return elem;
	}
	
	public static WebElement checkInDate(WebDriver driver)
	{
		elem=driver.findElement(By.id("checkInDateCheck"));
		return elem;
	}
	
	public static WebElement date1(WebDriver driver)
	{
		elem=driver.findElement(By.id("05/08/2022"));
		return elem;
	}
	
	public static WebElement date2(WebDriver driver)
	{
		elem=driver.findElement(By.id("08/08/2022"));
		return elem;
	}
	
	public static WebElement guests(WebDriver driver)
	{
		elem=driver.findElement(By.xpath("/html[1]/body[1]/div[2]/section[1]/div[1]/div[1]/div[2]/div[4]/div[1]/section[1]/div[3]/div[1]/div[2]/div[1]/div[1]/form[1]/ul[1]/li[5]/div[1]/label[1]"));
		return elem;
	}
	
	public static WebElement adultMinus(WebDriver driver)
	{
		elem=driver.findElement(By.xpath("/html[1]/body[1]/div[2]/section[1]/div[1]/div[1]/div[2]/div[4]/div[1]/section[1]/div[3]/div[1]/div[2]/div[1]/div[1]/form[1]/ul[1]/li[5]/div[1]/ul[1]/li[1]/ul[1]/li[1]/div[1]/div[1]/i[1]"));
		return elem;
	}
	
	public static WebElement childPlus(WebDriver driver)
	{
		elem=driver.findElement(By.xpath("/html[1]/body[1]/div[2]/section[1]/div[1]/div[1]/div[2]/div[4]/div[1]/section[1]/div[3]/div[1]/div[2]/div[1]/div[1]/form[1]/ul[1]/li[5]/div[1]/ul[1]/li[1]/ul[1]/li[2]/div[1]/div[3]/i[1]"));
		return elem;
	}
	
	public static WebElement ageOfChild1(WebDriver driver)
	{
		elem=driver.findElement(By.xpath("/html[1]/body[1]/div[2]/section[1]/div[1]/div[1]/div[2]/div[4]/div[1]/section[1]/div[3]/div[1]/div[2]/div[1]/div[1]/form[1]/ul[1]/li[5]/div[1]/ul[1]/li[1]/ul[1]/li[3]/div[1]/div[1]/div[1]/div[1]/select[1]"));
		return elem;
	}
	
	public static WebElement addRoom(WebDriver driver)
	{
		elem=driver.findElement(By.xpath("/html[1]/body[1]/div[2]/section[1]/div[1]/div[1]/div[2]/div[4]/div[1]/section[1]/div[3]/div[1]/div[2]/div[1]/div[1]/form[1]/ul[1]/li[5]/div[1]/ul[1]/li[2]/ul[1]/li[1]/a[1]"));
		return elem;
	}
	
	public static WebElement checkAvailability(WebDriver driver)
	{
		elem=driver.findElement(By.cssSelector("input[value='Check Availability']"));
		return elem;
	}
	
	public static WebElement removeRoom(WebDriver driver)
	{
		elem=driver.findElement(By.xpath("/html[1]/body[1]/div[2]/section[1]/div[1]/div[1]/div[2]/div[4]/div[1]/section[1]/div[3]/div[1]/div[2]/div[1]/div[1]/form[1]/ul[1]/li[5]/div[1]/ul[1]/li[2]/ul[1]/li[1]/a[2]"));
		return elem;
	}
	
	public static WebElement bookNow(WebDriver driver)
	{
		elem=driver.findElement(By.xpath("//*[@id=\"roomWrapper0001863006\"]/div[2]/div[5]/button"));
		return elem;
	}
	
	//
	//Payment
	//
	
	
	
	/*public static WebElement a(WebDriver driver)
	{
		elem=driver.findElement(By);
		return elem;
	}
	
	public static WebElement a(WebDriver driver)
	{
		elem=driver.findElement(By);
		return elem;
	}

	*/
}
