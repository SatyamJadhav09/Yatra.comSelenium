package Repository;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LoginCred
{
	public static WebElement element;
	
	public static WebElement Myaccount(WebDriver driver)
	{
		element=driver.findElement(By.className("dropdown-toggle"));
		return element;
	}
	public static WebElement login(WebDriver driver)
	{
		
		element=driver.findElement(By.id("signInBtn"));
		
		return element;
	}
	
	
	public static WebElement mobNo(WebDriver driver)
	{
		element=driver.findElement(By.id("login-input"));
		return element;
	}
	
	public static WebElement linkForPassword(WebDriver driver)
	{
		element=driver.findElement(By.xpath("/html[1]/body[1]/div[4]/section[1]/form[1]/div[3]/p[6]"));
		return element;
	}
	
	public static WebElement password(WebDriver driver)
	{
		element=driver.findElement(By.id("login-password"));
		return element;
	}
	public static WebElement continueOtp(WebDriver driver)
	{
		element=driver.findElement(By.id("login-continue-btn"));
		return element;
	}
	
	public static WebElement submit(WebDriver driver)
	{
		element=driver.findElement(By.id("verify-otp"));
		return element;
	}
	
	public static WebElement linkForLogout(WebDriver driver)
	{
		element=driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[1]/div[4]/div[2]/div[1]/ul[1]/li[1]/a[1]"));
		return element;
	}
	
	public static WebElement logout(WebDriver driver)
	{
		element=driver.findElement(By.linkText("Logout"));
		return element;
	}
	
	
	
	
	

}
