package Repository;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class PaymentRp
{
	public static WebElement elem;
	
	public static WebElement mail(WebDriver driver)
	{
		elem=driver.findElement(By.id("additionalContactEmail"));
		return elem;
	}
	
	public static WebElement mobNo(WebDriver driver)
	{
		elem=driver.findElement(By.id("additionalContactMobile"));
		return elem;
	}
	
	public static WebElement title(WebDriver driver)
	{
		elem=driver.findElement(By.xpath("//body/div[2]/div[2]/div[1]/div[1]/div[1]/div[7]/main[1]/div[1]/div[1]/div[3]/form[1]/div[1]/div[1]/div[1]/article[2]/div[2]/div[1]/span[1]/select[1]"));
		return elem;
	}
	
	public static WebElement firstName(WebDriver driver)
	{
		elem=driver.findElement(By.id("travellerf0"));
		return elem;
	}
	
	public static WebElement lastName(WebDriver driver)
	{
		elem=driver.findElement(By.id("travellerl0"));
		return elem;
	}
	
	public static WebElement continueForPayment(WebDriver driver)
	{
		elem=driver.findElement(By.xpath("//body/div[2]/div[2]/div[1]/div[1]/div[1]/div[7]/main[1]/div[1]/div[1]/div[3]/form[1]/div[4]/button[1]"));
		return elem;
	}
	
	public static WebElement gPay(WebDriver driver)
	{
		elem=driver.findElement(By.id("tez"));
		return elem;
	}
	
	public static WebElement mobNoOfGPay(WebDriver driver)
	{
		elem=driver.findElement(By.id("payerVAMobile"));
		return elem;
	}
	
	public static WebElement payNow(WebDriver driver)
	{
		elem=driver.findElement(By.id("payNow"));
		return elem;
	}
	
	public static WebElement paymentWithoutPromocode(WebDriver driver)
	{
		elem=driver.findElement(By.id("ContinueWithoutPromo"));
		return elem;
	}
	
	public static WebElement paymentInitiated(WebDriver driver)
	{
		elem=driver.findElement(By.xpath("/html[1]/body[1]/div[33]/h3[1]/span[1]"));
		return elem;
	}
	
}
