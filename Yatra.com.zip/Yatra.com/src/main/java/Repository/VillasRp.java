package Repository;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class VillasRp 
{
	public static WebElement elem;
	public static WebElement hotelsNVillas(WebDriver driver)
	{
		elem=driver.findElement(By.id("booking_engine_homestays"));
		return elem;
	}
	
	public static WebElement searchVillas(WebDriver driver)
	{
		elem=driver.findElement(By.id("BE_hotel_htsearch_btn"));
		return elem;
	}
	
	public static WebElement priceRange(WebDriver driver)
	{
		elem=driver.findElement(By.xpath("//body/div[@id='bongo-hotel-wrapper']/section[@id='wrapper']/div[1]/div[1]/aside[2]/div[1]/div[2]/div[3]/div[1]/div[1]/div[1]/div[1]/ul[1]/li[6]/label[1]"));
		return elem;
	}
	
	public static WebElement freeWiFi(WebDriver driver)
	{
		elem=driver.findElement(By.xpath("//body/div[@id='bongo-hotel-wrapper']/section[@id='wrapper']/div[1]/div[1]/aside[2]/div[1]/div[2]/div[7]/div[1]/div[1]/div[1]/div[1]/div[1]/ul[1]/li[3]/label[1]"));
		return elem;
	}
	
	public static WebElement localities(WebDriver driver)
	{
		elem=driver.findElement(By.xpath("/html[1]/body[1]/div[2]/section[1]/div[1]/div[1]/aside[2]/div[1]/div[2]/div[9]/div[1]/div[1]/div[1]/div[1]/div[1]/ul[1]/li[2]/label[1]"));
		return elem;
	}
	
	public static WebElement homeStays(WebDriver driver)
	{
		elem=driver.findElement(By.xpath("//body/div[@id='bongo-hotel-wrapper']/section[@id='wrapper']/div[1]/div[1]/aside[2]/div[1]/div[2]/div[10]/div[1]/div[1]/div[1]/div[1]/div[1]/ul[1]/li[1]/label[1]"));
		return elem;
	}
	
	public static WebElement HomestayName(WebDriver driver)
	{
		elem=driver.findElement(By.xpath("/html[1]/body[1]/div[2]/section[1]/div[1]/div[1]/div[3]/div[1]/div[2]/div[1]/article[2]/div[1]/div[1]/div[1]/h2[1]/a[1]"));
		return elem;
	}
	
	public static WebElement scrollLocalities(WebDriver driver)
	{
		elem=driver.findElement(By.id("mega-filter-open-close-localities"));
		return elem;
	}
	
	public static WebElement scrollPropertyType(WebDriver driver)
	{
		elem=driver.findElement(By.id("mega-filter-open-close-ctg"));
		return elem;
	}
	
	public static WebElement checkAvailability(WebDriver driver)
	{
		elem=driver.findElement(By.xpath("/html[1]/body[1]/div[2]/section[1]/div[1]/div[1]/div[2]/div[5]/div[1]/section[1]/div[3]/div[1]/div[1]/div[1]/div[1]/form[1]/ul[1]/li[6]/input[1]"));
		return elem;
	}
	
	public static WebElement bookNow(WebDriver driver)
	{
		elem=driver.findElement(By.xpath("/html[1]/body[1]/div[2]/section[1]/div[1]/div[1]/div[2]/div[5]/div[1]/section[1]/div[3]/div[2]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/ul[1]/li[1]/div[2]/div[5]/button[1]"));
		return elem;
	}
	

	
	/*public static WebElement e(WebDriver driver)
	{
		elem=driver.findElement(By);
		return elem;
	}
	
	
	
	public static WebElement e(WebDriver driver)
	{
		elem=driver.findElement(By);
		return elem;
	}
	
	public static WebElement e(WebDriver driver)
	{
		elem=driver.findElement(By);
		return elem;
	}
	
	public static WebElement e(WebDriver driver)
	{
		elem=driver.findElement(By);
		return elem;
	}
	
	public static WebElement e(WebDriver driver)
	{
		elem=driver.findElement(By);
		return elem;
	}
	
	public static WebElement e(WebDriver driver)
	{
		elem=driver.findElement(By);
		return elem;
	}
	
	public static WebElement e(WebDriver driver)
	{
		elem=driver.findElement(By);
		return elem;
	}
	
	public static WebElement e(WebDriver driver)
	{
		elem=driver.findElement(By);
		return elem;
	}*/
}
