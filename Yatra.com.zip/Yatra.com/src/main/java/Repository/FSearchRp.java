package Repository;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class FSearchRp
{
	public static WebElement elem;
	
	public static WebElement tripType(WebDriver driver)	
	{
		elem=driver.findElement(By.xpath("//body/div[2]/div[1]/section[1]/div[1]/div[1]/div[1]/section[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/ul[1]/li[2]/a[1]"));
		return elem;
	}
	
	public static WebElement dpartFrom(WebDriver driver)
	{
		elem=driver.findElement(By.id("BE_flight_origin_city"));
		return elem;	
	}
	
	public static WebElement arriveAt(WebDriver driver)
	{
		elem=driver.findElement(By.id("BE_flight_arrival_city"));
		return elem;
	}
	
	public static WebElement onBoardDate(WebDriver driver)
	{
		elem=driver.findElement(By.id("BE_flight_origin_date"));
		return elem;
	}
	
	public static WebElement date1(WebDriver driver)
	{
		elem=driver.findElement(By.id("14/07/2022"));
	//	elem=driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/section[1]/div[1]/div[1]/div[1]/section[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/ul[1]/li[2]/ul[1]/li[1]/section[1]/div[1]/div[2]/div[2]/div[2]/div[1]/div[1]/div[1]/table[1]/tbody[1]/tr[2]/td[3]"));
		return elem;
	}
	
	public static WebElement returnDate(WebDriver driver)
	{
		elem=driver.findElement(By.id("BE_flight_arrival_date"));
		return elem;
	}
	

	public static WebElement date2(WebDriver driver)
	{
		elem= driver.findElement(By.id("22/07/2022"));
		//elem=driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/section[1]/div[1]/div[1]/div[1]/section[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/ul[1]/li[2]/ul[1]/li[3]/section[1]/div[1]/div[2]/div[2]/div[2]/div[1]/div[1]/div[1]/table[1]/tbody[1]/tr[3]/td[2]"));
		
		return elem;
	}
	
	public static WebElement numberOfSits(WebDriver driver)
	{
		elem=driver.findElement(By.xpath("//body/div[2]/div[1]/section[1]/div[1]/div[1]/div[1]/section[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]/i[1]"));
		return elem;
	}
	public static WebElement adultsPlus(WebDriver driver)
	{
		elem=driver.findElement(By.xpath("//body/div[2]/div[1]/section[1]/div[1]/div[1]/div[1]/section[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/span[2]"));
		return elem;
	}
	
	public static WebElement childPlus(WebDriver driver)
	{
		elem= driver.findElement(By.xpath("//body/div[2]/div[1]/section[1]/div[1]/div[1]/div[1]/section[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/span[2]"));
		return elem;
	}
	
	public static WebElement infantPlus(WebDriver driver)
	{
		elem=driver.findElement(By.xpath("//body/div[2]/div[1]/section[1]/div[1]/div[1]/div[1]/section[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[1]/div[3]/div[1]/div[1]/span[2]"));
		return elem;
	}
	
	public static WebElement preEco(WebDriver driver)
	{
		elem=driver.findElement(By.xpath("//body/div[2]/div[1]/section[1]/div[1]/div[1]/div[1]/section[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[2]/div[1]/div[1]/ul[1]/li[2]/span[1]"));
		return elem;
	}
	
	public static WebElement nonStopFlights(WebDriver driver)
	{
		elem=driver.findElement(By.cssSelector("a[title='Non Stop Flights']"));
		return elem;
	}
	
	public static WebElement flightSearch(WebDriver driver)
	{
		elem=driver.findElement(By.id("BE_flight_flsearch_btn"));
		return elem;
	}
	
	
}
