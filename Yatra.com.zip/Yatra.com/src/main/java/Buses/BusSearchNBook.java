package Buses;

import java.io.File;
import java.io.IOException;
import java.time.Duration;

import org.apache.commons.io.FileUtils;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import Repository.BusesRp;
import file.read.pkg.FileRead;
import io.github.bonigarcia.wdm.WebDriverManager;

public class BusSearchNBook
{

	public static void main(String[] args) throws IOException, InterruptedException
	{
		WebDriverManager.edgedriver().setup();
		WebDriver driver=new EdgeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.yatra.com/");
		/*  Kolhapur
																			Mumbai
																			Delhi
																			Goa
																			Pune
																			Ladakh
		 */

		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		try
		{
			driver.switchTo().frame("webpush-onsite");
			driver.findElement(By.xpath("/html/body/div/div[2]/div[2]/button[1]")).click();
		}
		catch(Exception e)
		{
			driver.close();
		}
		driver.switchTo().parentFrame();

		XSSFSheet sh1=FileRead.readF("Destinations");
		String city1=sh1.getRow(1).getCell(0).toString();
		String city2=sh1.getRow(4).getCell(0).toString();
		System.out.println(city1+" , "+city2);


		BusesRp.busesIcon(driver).click();
		BusesRp.departFrom(driver).click();
		Thread.sleep(3000);
		BusesRp.departFrom(driver).sendKeys(city1);
		Thread.sleep(5000);
		BusesRp.departFrom(driver).sendKeys(Keys.ENTER);
		Thread.sleep(5000);
		BusesRp.goingTo(driver).sendKeys(city2);
		Thread.sleep(5000);
		BusesRp.goingTo(driver).sendKeys(Keys.ENTER);
		Thread.sleep(5000);

		BusesRp.departDate(driver).click();
		BusesRp.date(driver).click();

		BusesRp.busSearchButton(driver).click();
		System.out.println("Bus search complete");

		WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(20));
		wait.until(ExpectedConditions.visibilityOf(BusesRp.manishTravels(driver)));
		JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("arguments[0].scrollIntoView;", BusesRp.manishTravels(driver));
		BusesRp.selectSeat(driver).click();
		System.out.println("Bus selected");

		try
		{
			
		
			BusesRp.seat1(driver).click();
			BusesRp.seat2(driver).click();
			Select elem=new Select(BusesRp.selectBoardingPoint(driver));
			elem.selectByIndex(1);

			Select elem2=new Select(BusesRp.selectDroppingPoints(driver));
			elem2.selectByIndex(1);
			BusesRp.conformSeats(driver).click();
		
		}
		
		catch(Exception e)
		{
			System.out.println("All seats are booked");
			File fs=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE); //Taking screenshot
			FileUtils.copyFile(fs,new File("C:\\Users\\HP\\Desktop\\busSelectFailed.png"));
			driver.close();
		}
		
		Thread.sleep(5000);
		File fs=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(fs,new File("C:\\Users\\HP\\Desktop\\BusConfirmAmountDetails.png"));
		System.out.println("Success!");
		driver.close();
		/*BusesRp
		BusesRp*/
	}

}